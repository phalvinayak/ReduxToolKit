const book = {
    author: "Robert Kiyosaki",
    book: {
        name: "Rich Dad Poor Dad",
        price: "$8",
        rating: 4.7,
    },
};

const arrayOfBooks = ["Book1", "Book2", "Book3"];
