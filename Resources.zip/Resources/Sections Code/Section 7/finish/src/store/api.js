import { createAction } from "@reduxjs/toolkit";

export const apiCallBegan = createAction("api/callBegan");
